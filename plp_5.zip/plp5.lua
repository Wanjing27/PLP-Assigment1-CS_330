function multip(x,y)
    answer=x*y
    print (answer)
    return answer
end

multip(2,5)

function recur(x)
    if x<4 then 
        x=x+1
        recur(x)
        print("variable is less than 4")
    else
        print("variable is bigger than 4")
    end
end 

recur(2)

function cutString(x)
   y= math.floor((string.len(x)/2)+0.5)
   s1=string.sub(x,1,y)
   s2=string.sub(x,y+1,string.len(x))
   return s1,s2
end

string1, string2=cutString("I'd rather be a bird than a fish.")
print(string1)
print(string2)

function main()
    multip(4,5)
end 

main()

function changValue(x,y)
    temp = x
    x = y
    y = temp
end 

function passBy()
    x=1
    y=0
    changValue(x)
    if x ==1 then
        print("Pass by Value")
    else 
        print("Pass by Reference")
    end 
end

passBy()