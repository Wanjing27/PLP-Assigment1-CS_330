x=3
print("original x="..x)
for x=0,5 do
    x=x+1
    print("in for loop x="..x)
end 
print("outside of for loop x="..x)

function changeX()
    x=x+1
    print ("in function x="..x)
end 

changeX()

print("outside the function x="..x)

a = {'c','a','t'} 	
b = {'d','o','g'} 
a=b 
b[1] = 'u' 
print("Char a:")
for i,v in ipairs(a) do 
    print(i,v) 
end
print("Char b:")
for i,v in ipairs(b) do 
    print(i,v) 
end
    